Codex Responses completion proof — 2026-11-16

Actual path: Codex CLI -> transparent capture proxy -> full tingly-box gateway
-> native OpenAI Responses transport -> vmodel benchmark ScenarioServer.
No real model/API credentials are used. The capture proxy does not rewrite SSE.

Binary: codex-cli 0.159.0-alpha.3
Baseline: 167d3867819e10da479460674bedf45120aa1e0a
Fix: 12a1b76d81e121eaaf880e236036c456fb7917c3
Experiment source: 362091f8 (full revision is in each manifest).
The before stage replaces only openai_passthrough.go using a Go source overlay;
the test, gateway setup, SDKs and Codex executable are otherwise identical.

Results (default matrix allows 1 retry):
- Valid usage: success before and after, 1 request, 0 retries.
- Absent usage: success before and after, 1 request, 0 retries.
- Null usage: before fails after 2 requests; after succeeds with 1 request.
- Null counters: before fails after 2 requests; after succeeds with 1 request.
- Truncated stream: fails before and after, no fabricated completion.
- Original 5-retry pattern: null usage before makes 6 requests and logs
  Reconnecting 1/5 through 5/5 then turn.failed; after makes 1 request,
  logs no reconnects and ends with turn.completed.

All 12 case runs met assertions. Both stages' upstream fixtures are byte-identical.
The expected failures make the Go tests PASS: these are negative controls.
Exit codes, actual upstream Responses hits, gateway request counts, marker text,
turn events and reconnect counts are all independently checked. Chat endpoint
hits must be zero. Merely printing answer text does not count as success.

Contents:
- matrix/ and five-retries/: manifests, handler snapshots, test logs and case data.
- Each case: upstream.sse, gateway-N.sse, codex.stdout.jsonl,
  codex.stderr.log, request-N.json (method/path/body hash; no auth headers), result.json.
- SHA256SUMS in each run: verifies the retained evidence (sha256sum -c SHA256SUMS).
- source/: exact test and Python runner used in the experiment.

The standalone Codex metadata warning for the synthetic tingly-codex model is
present in successful and failed controls alike; it is not a completion failure.
Startup plugin/network warnings in stderr are not used as failure verdicts.

Reproduce from a tingly-box checkout with the included test/runner and Go:
python3 tests/codex-responses-completion-proof.py --codex /path/to/codex \
  --baseline 167d3867819e10da479460674bedf45120aa1e0a --output /tmp/new-proof
python3 tests/codex-responses-completion-proof.py --codex /path/to/codex \
  --baseline 167d3867819e10da479460674bedf45120aa1e0a \
  --output /tmp/new-proof-five --case null-usage --retries 5

The output directories must not already exist. Codex receives a fresh config
home and a synthetic credential for each run; no user config is modified.
These results establish this synthetic defect and fix. They do not establish
the root cause of an unobserved deployment or cover every Codex version/provider.
